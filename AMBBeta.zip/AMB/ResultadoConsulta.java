import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.util.List;
import java.util.Vector;

import javax.swing.JTable;


public class ResultadoConsulta {
	Vector <Vector<String>> datos = null;
	Vector <String> nombreColumna = null;
	
	public ResultadoConsulta (List<Abm> l) {
		datos = new Vector<Vector<String>>();
		for (Abm a : l) {
			datos.add(a.getDatos());
		}
		Field[] f = Abm.class.getDeclaredFields();
		nombreColumna = new Vector<String>();
		for (Field field : f) {
			nombreColumna.add(field.getName());
		}

	}
	
	public JTable getTable(){
		return new JTable(datos,nombreColumna);
	}
	
	public Abm getAbm(int i){
		return new Abm(datos.get(i));
	}

}
