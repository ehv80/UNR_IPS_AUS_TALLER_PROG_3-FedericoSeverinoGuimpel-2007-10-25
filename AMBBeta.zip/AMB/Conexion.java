import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.RootPaneContainer;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mysql.jdbc.ResultSet;


public class Conexion {
		private static Session s;
		private static SessionFactory sf;
		
	public static void conectar()
	{
		sf = new Configuration().configure().buildSessionFactory();
		s = sf.openSession();
	}

	public static void desconectar()
	{
		s.close();
		sf.close();
	}
	
	public static void agregar(Abm a) throws SQLException{
		
		try 
		{
			Transaction t = s.beginTransaction();
			s.save(a);
			t.commit();
		} catch (HibernateException e) 
		{
			JOptionPane.showMessageDialog(null,"El cliente ya existe en la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public static void actualizar(Abm a) throws SQLException
	{
		try 
		{
			Transaction t = s.beginTransaction();
			s.saveOrUpdate(a);
			t.commit();
		} catch (HibernateException e) 
		{
			JOptionPane.showMessageDialog(null, "Error en la conexion...", "Error", JOptionPane.ERROR_MESSAGE);
		}		
	}

	public static void eliminar(Abm a) throws SQLException
	{
		try 
		{
			Transaction t = s.beginTransaction();
			s.delete(a);
			t.commit();
		} catch (HibernateException e) 
		{
			JOptionPane.showMessageDialog(null, "Error en la conexion...", "Error", JOptionPane.ERROR_MESSAGE);
		}		
	}

	public static ResultadoConsulta consulta(String consulta) throws SQLException
	{
		if (s==null) 
		{
			conectar();
		}
		if(s!=null)
		{
			return new ResultadoConsulta(s.createQuery(consulta).list());
		}
		return null;
	}
}
