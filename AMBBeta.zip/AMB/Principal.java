import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.BorderFactory;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.border.BevelBorder;

public class Principal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JDesktopPane jDesktopPane = null;
	private JMenuBar jJMenuBar = null;
	private JMenu jMenu = null;
	private JMenuItem jMenuItem = null;
	private JMenuItem jMenuItem1 = null;
	private JMenuItem jMenuItem2 = null;
	private JMenuItem jMenuItem3 = null;
	/**
	 * This is the default constructor
	 */
	public Principal() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(599, 343);
		this.setBackground(new Color(179, 65, 65));
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/logopoli.jpg")));
		this.setResizable(false);
		this.setJMenuBar(getJJMenuBar());
		this.setContentPane(getJDesktopPane());
		this.setTitle("Principal - ABM");
		
	}

	/**
	 * This method initializes jDesktopPane	
	 * 	
	 * @return javax.swing.JDesktopPane	
	 */
	private JDesktopPane getJDesktopPane() {
		if (jDesktopPane == null) {
			jDesktopPane = new JDesktopPane();
			jDesktopPane.setBackground(new Color(196, 198, 200));
			
		}
		return jDesktopPane;
	}

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jJMenuBar.add(getJMenu());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenu() {
		if (jMenu == null) {
			jMenu = new JMenu();
			jMenu.setText("Opciones");
			jMenu.add(getJMenuItem());
			jMenu.add(getJMenuItem1());
			jMenu.add(getJMenuItem2());
			jMenu.add(getJMenuItem3());
		}
		return jMenu;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem() {
		if (jMenuItem == null) {
			jMenuItem = new JMenuItem();
			jMenuItem.setText("Altas");
			jMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					boolean estaActivo = false;
					JInternalFrame frames [] = jDesktopPane.getAllFrames();
					
					for ( int i = 0 ; i < frames.length; i++) {
						if (frames[i] instanceof Altas) {
							frames[i].toFront();
							estaActivo = true;
						} 
					}
					
					if (estaActivo == false) {
						Altas a = new Altas();
						a.setVisible(true);
						jDesktopPane.add(a);
					}
				}
			});
		}
		return jMenuItem;
	}

	/**
	 * This method initializes jMenuItem1	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem1() {
		if (jMenuItem1 == null) {
			jMenuItem1 = new JMenuItem();
			jMenuItem1.setText("Bajas");
			jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					boolean estaActivo = false;
					JInternalFrame frames [] = jDesktopPane.getAllFrames();
					
					for ( int i = 0 ; i < frames.length; i++) {
						if (frames[i] instanceof Bajas) {
							frames[i].toFront();
							estaActivo = true;
						} 
					}
					
					if (estaActivo == false) {
						Bajas b = new Bajas(jDesktopPane);
						b.setVisible(true);
						jDesktopPane.add(b);
					}
				}
			});
		}
		return jMenuItem1;
	}

	/**
	 * This method initializes jMenuItem2	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem2() {
		if (jMenuItem2 == null) {
			jMenuItem2 = new JMenuItem();
			jMenuItem2.setText("Modificaciones");
			jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					boolean estaActivo = false;
					JInternalFrame frames [] = jDesktopPane.getAllFrames();
					
					for ( int i = 0 ; i < frames.length; i++) {
						if (frames[i] instanceof Modificaciones) {
							frames[i].toFront();
							estaActivo = true;
						} 
					}
					
					if (estaActivo == false) {
						//Le pasamos al constructor de Modificaciones la referencia a jDesktopPane
						Modificaciones m = new Modificaciones(jDesktopPane);
						m.setVisible(true);
						jDesktopPane.add(m);
					}
				}
				
			});
		}
		return jMenuItem2;
	}

	/**
	 * This method initializes jMenuItem3	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem3() {
		if (jMenuItem3 == null) {
			jMenuItem3 = new JMenuItem();
			jMenuItem3.setText("Salir");
			jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					JOptionPane.showMessageDialog(jDesktopPane, "Gracias por usar ABM");
					dispose();
				}
			});
		}
		return jMenuItem3;
	}
	
	public static void main(String[] args) {
		Principal Principal = new Principal();
		Principal.setVisible(true);
		
	}
} 
