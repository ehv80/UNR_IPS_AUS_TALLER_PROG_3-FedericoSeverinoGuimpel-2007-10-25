import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;


public class ResultSetToVector {
	public static Vector<Vector> getDatos(ResultSet r) {
		Vector<Vector> datos = new Vector<Vector>();
		try {
			ResultSetMetaData m = r.getMetaData();
			Vector<Object> temp;
			int numColumnas = m.getColumnCount();
			while(r.next()){
				temp = new Vector<Object>();
				for(int i=1; i<=numColumnas; i++){
					temp.add(r.getObject(i));
				}
				datos.add(temp);
			}
			return datos;
		} catch (SQLException e) {
			return null;
		}
	}
	
	
	public static Vector<String> getColumnas(ResultSet r) {
		Vector<String> datos = new Vector<String>();
		try {
			ResultSetMetaData m = r.getMetaData();
			int numColumnas = m.getColumnCount();
			for(int i=1; i<=numColumnas; i++){
					datos.add(m.getColumnName(i));
			}
			return datos;
		} catch (SQLException e) {
			return null;
		}
	}

}
