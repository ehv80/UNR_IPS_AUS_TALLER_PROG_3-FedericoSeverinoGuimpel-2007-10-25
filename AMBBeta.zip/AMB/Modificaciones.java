import java.awt.Rectangle;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

public class Modificaciones extends JInternalFrame {

	private JPanel jContentPane = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	JTextField jTextFieldNombre = null;
	private JComboBox jComboBox = null;
	private JLabel jLabel2 = null;
	JTextField jTextFieldApellido = null;
	JTextField jTextFieldDni = null;
	JTextField jTextFieldEdad = null;
	private JButton jButton = null;
	private JButton jButton1 = null;
	private JPanel jPanel = null;
	private JButton jButton2 = null;
	private VentanaSeleccion v = null;
	protected JDesktopPane jDesktopPane = null;
	private String dni = null;
	/**
	 * This is the xxx default constructor
	 */
	public Modificaciones(JDesktopPane jDesktopPane) {
		super();
		this.jDesktopPane = jDesktopPane;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(278, 176);
		this.setAlignmentY(15.0F);
		this.setAlignmentX(15.0F);
		this.setFrameIcon(new ImageIcon(getClass().getResource("/modusr_l.gif")));
		this.setTitle("Modificaciones");
		this.setContentPane(getJContentPane());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(15, 88, 55, 18));
			jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel2.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel2.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jLabel2.setText("Edad");
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(15, 36, 55, 18));
			jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel1.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jLabel1.setText("Apellido");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(15, 10, 55, 18));
			jLabel.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jLabel.setText("Nombre");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.setOpaque(true);
			jContentPane.setAlignmentX(5.0F);
			jContentPane.setAlignmentY(5.0F);
			jContentPane.add(jLabel, null);
			jContentPane.add(jLabel1, null);
			jContentPane.add(getJTextFieldNombre(), null);
			jContentPane.add(getJComboBox(), null);
			jContentPane.add(jLabel2, null);
			jContentPane.add(getJTextFieldApellido(), null);
			jContentPane.add(getJTextFieldDni(), null);
			jContentPane.add(getJTextFieldEdad(), null);
			jContentPane.add(getJPanel(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jTextFieldNombre	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private  JTextField getJTextFieldNombre() {
		if (jTextFieldNombre == null) {
			jTextFieldNombre = new JTextField();
			jTextFieldNombre.setBounds(new Rectangle(76, 11, 180, 18));
			jTextFieldNombre.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		}
		return jTextFieldNombre;
	}

	/**
	 * This method initializes jComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBox() {
		if (jComboBox == null) {
			jComboBox = new JComboBox();
			jComboBox.setBounds(new Rectangle(15, 59, 55, 22));
			jComboBox.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jComboBox.addItem("DNI");
			jComboBox.addItem("LC");
			jComboBox.addItem("LE");
		}
		return jComboBox;
	}

	/**
	 * This method initializes jTextFieldApellido	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldApellido() {
		if (jTextFieldApellido == null) {
			jTextFieldApellido = new JTextField();
			jTextFieldApellido.setBounds(new Rectangle(76, 36, 180, 18));
			jTextFieldApellido.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		}
		return jTextFieldApellido;
	}

	/**
	 * This method initializes jTextFieldDni	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldDni() {
		if (jTextFieldDni == null) {
			jTextFieldDni = new JTextField();
			jTextFieldDni.setBounds(new Rectangle(76, 60, 180, 21));
			jTextFieldDni.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		}
		return jTextFieldDni;
	}

	/**
	 * This method initializes jTextFieldEdad	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldEdad() {
		if (jTextFieldEdad == null) {
			jTextFieldEdad = new JTextField();
			jTextFieldEdad.setBounds(new Rectangle(76, 87, 180, 18));
			jTextFieldEdad.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		}
		return jTextFieldEdad;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(186, 5, 80, 21));
			jButton.setText("Salir");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					dispose();
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setBounds(new Rectangle(-4, 5, 80, 21));
			jButton1.setText("Buscar");
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					ResultadoConsulta r;

					try {
						String str_query="SELECT p from Abm as p WHERE 1=1 ";
						
						if (!jTextFieldNombre.getText().equals("")) str_query+=" AND p.nombre='" + jTextFieldNombre.getText()+"'";
						if (!jTextFieldApellido.getText().equals("")) str_query+=" AND p.apellido='" + jTextFieldApellido.getText()+"'";
						if (!jTextFieldEdad.getText().equals("")) str_query+=" AND p.edad='" + jTextFieldEdad.getText()+"'";
						if (!jTextFieldDni.getText().equals("")) str_query+=" AND p.ndoc='" + jTextFieldDni.getText()+"'";
						
						Conexion.conectar();
						r = Conexion.consulta(str_query);
						Conexion.desconectar();
						v = new VentanaSeleccion(r, estaVentana());
						jDesktopPane.add(v);
						v.setVisible(true);
						jButton2.setEnabled(true);
						setVisible(false);
					} catch (SQLException e1) {
						e1.printStackTrace();
					}							 
				
				}}
			);
		}
		return jButton1;
	}

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	
	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setLayout(null);
			jPanel.setBounds(new Rectangle(1, 111, 267, 33));
			jPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jPanel.add(getJButton(), null);
			jPanel.add(getJButton1(), null);
			jPanel.add(getJButton2(), null);
		}
		return jPanel;
	}

	/**
	 * This method initializes jButton2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton2() {
		if (jButton2 == null) {
			jButton2 = new JButton();
			jButton2.setBounds(new Rectangle(85, 5, 92, 21));
			jButton2.setText("Modificar");
			jButton2.setEnabled(false);
			jButton2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (!jTextFieldNombre.getText().equals("") && !jTextFieldApellido.getText().equals("") && !jTextFieldDni.getText().equals("") && !jTextFieldEdad.getText().equals("")){
						
						if ((jTextFieldNombre.getText().length() <= 20) && (jTextFieldApellido.getText().length() <= 20) && (jTextFieldDni.getText().length() <= 10) && (jTextFieldEdad.getText().length() <= 2)){
							
							try {
								Integer.parseInt(jTextFieldDni.getText());
								Integer.parseInt(jTextFieldEdad.getText());
																
								try {
									
									int i = JOptionPane.showConfirmDialog(rootPane, 
											"�Quiere Modificar el cliente "+dni+"?", "Modificar Registro",
											JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
									
									if( i == 0 ){
										Abm deleteA = new Abm(dni," "," "," ",0);
										Abm newA = new Abm(jTextFieldDni.getText(),jTextFieldNombre.getText(),jTextFieldApellido.getText(),(String)jComboBox.getSelectedItem(),Integer.parseInt(jTextFieldEdad.getText()));
										Conexion.conectar();
										Conexion.eliminar(deleteA);
										Conexion.agregar(newA);
										Conexion.desconectar();
										jButton2.setEnabled(false);
									}
									if ( i == 1 ){
										JOptionPane.showMessageDialog(rootPane, "El cliente "+dni+" no fue modificado");
									}
										
																
								} catch (SQLException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
																								
							} catch (NumberFormatException e3){
								JOptionPane.showMessageDialog(rootPane, "Num. de Decumento y Edad \ntienen que ser n�mericos", "Error", JOptionPane.ERROR_MESSAGE);
							}
						}else {
							JOptionPane.showMessageDialog(rootPane, "Datos ingresados exceden el m�ximo permitido", "Error", JOptionPane.ERROR_MESSAGE);}
					}else {
						JOptionPane.showMessageDialog(rootPane, "Los campos no pueden estar en blanco", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
			});
		}
		return jButton2;
	}
	public Modificaciones estaVentana() {
		return this;
	}
	
	
	public void cargaDatos(Abm a) {
		setVisible(true);
		dni = a.getNdoc(); //Guarda dni para modificacion
		jTextFieldNombre.setText(a.getNombre());
		jTextFieldApellido.setText(a.getApellido());
		jComboBox.setSelectedItem(a.getTdoc());
		jTextFieldDni.setText(a.getNdoc());
		jTextFieldEdad.setText(new Integer(a.getEdad()).toString());
		
	}

} 
