import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import java.awt.Rectangle;
import javax.swing.JTable;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.BorderFactory;
import javax.swing.border.BevelBorder;
import java.awt.Color;

public class VentanaSeleccion extends JInternalFrame {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JScrollPane jScrollPane = null;

	private JTable jTable = null;

	private ResultadoConsulta res;

	private Modificaciones m = null;
	
	private Bajas b = null;
	/**
	 * This is the default constructor
	 * @param texNombre 
	 * @param r 
	 */

	public VentanaSeleccion(ResultadoConsulta res, Modificaciones m) {
		super();
		initialize();
		this.m = m;
		this.res=res;
    	jTable = res.getTable();
		jTable.addMouseListener(new java.awt.event.MouseAdapter() {
			
			public void mouseClicked(java.awt.event.MouseEvent e) {
				
				Abm a = getRes().getAbm(jTable.getSelectedRow());
				getM().cargaDatos(a);
				setVisible(false);
				
			}
		}
		);
		jScrollPane.setViewportView(jTable);
	}
	
	public VentanaSeleccion(ResultadoConsulta res, Bajas b) {
		super();
		initialize();
		this.b = b;
		this.res=res;
    	jTable = res.getTable();
		jTable.addMouseListener(new java.awt.event.MouseAdapter() {
			
			public void mouseClicked(java.awt.event.MouseEvent e) {
				
				Abm a = getRes().getAbm(jTable.getSelectedRow());
				getB().cargaDatos(a);
				setVisible(false);
				
			}
		}
		);
		jScrollPane.setViewportView(jTable);
	}

	public ResultadoConsulta getRes() {
		return this.res;
	}
	
	public Modificaciones getM() {
		return this.m;
	}
	
	public Bajas getB() {
		return this.b;
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(440, 258);
		this.setBackground(new Color(153, 153, 153));
		this.setFrameIcon(new ImageIcon(getClass().getResource("/bino.gif")));
		this.setContentPane(getJContentPane());
		this.setTitle("Consulta Base de Datos");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJScrollPane(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(9, 8, 410, 204));
			jScrollPane.setViewportView(getJTable());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes jTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTable() {
		if (jTable == null) {
			jTable = new JTable();
			jTable.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		}
		return jTable;
	}

}  //  @jve:decl-index=0:visual-constraint="19,26"
