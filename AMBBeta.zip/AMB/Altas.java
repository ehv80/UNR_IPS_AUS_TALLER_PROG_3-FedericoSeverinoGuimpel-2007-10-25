import java.awt.Rectangle;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

public class Altas extends JInternalFrame {

	private JPanel jContentPane = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JTextField jTextFieldNombre = null;
	private JComboBox jComboBox = null;
	private JLabel jLabel2 = null;
	private JTextField jTextFieldApellido = null;
	private JTextField jTextFieldDni = null;
	private JTextField jTextFieldEdad = null;
	private JButton jButton = null;
	private JButton jButton1 = null;
	private JPanel jPanel = null;
	/**
	 * This is the xxx default constructor
	 */
	public Altas() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(278, 176);
		this.setAlignmentY(15.0F);
		this.setAlignmentX(15.0F);
		this.setFrameIcon(new ImageIcon(getClass().getResource("/addusr_l.gif")));
		this.setTitle("Alta");
		this.setContentPane(getJContentPane());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(15, 88, 55, 18));
			jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel2.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel2.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jLabel2.setText("Edad");
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(15, 36, 55, 18));
			jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel1.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jLabel1.setText("Apellido");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(15, 10, 55, 18));
			jLabel.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jLabel.setText("Nombre");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.setOpaque(true);
			jContentPane.setAlignmentX(5.0F);
			jContentPane.setAlignmentY(5.0F);
			jContentPane.add(jLabel, null);
			jContentPane.add(jLabel1, null);
			jContentPane.add(getJTextFieldNombre(), null);
			jContentPane.add(getJComboBox(), null);
			jContentPane.add(jLabel2, null);
			jContentPane.add(getJTextFieldApellido(), null);
			jContentPane.add(getJTextFieldDni(), null);
			jContentPane.add(getJTextFieldEdad(), null);
			jContentPane.add(getJPanel(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jTextFieldNombre	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldNombre() {
		if (jTextFieldNombre == null) {
			jTextFieldNombre = new JTextField();
			jTextFieldNombre.setBounds(new Rectangle(76, 11, 180, 18));
			jTextFieldNombre.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		}
		return jTextFieldNombre;
	}

	/**
	 * This method initializes jComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBox() {
		if (jComboBox == null) {
			jComboBox = new JComboBox();
			jComboBox.setBounds(new Rectangle(15, 59, 55, 23));
			jComboBox.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jComboBox.addItem("DNI");
			jComboBox.addItem("LC");
			jComboBox.addItem("LE");
		}
		return jComboBox;
	}

	/**
	 * This method initializes jTextFieldApellido	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldApellido() {
		if (jTextFieldApellido == null) {
			jTextFieldApellido = new JTextField();
			jTextFieldApellido.setBounds(new Rectangle(76, 36, 180, 18));
			jTextFieldApellido.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		}
		return jTextFieldApellido;
	}

	/**
	 * This method initializes jTextFieldDni	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldDni() {
		if (jTextFieldDni == null) {
			jTextFieldDni = new JTextField();
			jTextFieldDni.setBounds(new Rectangle(76, 60, 180, 21));
			jTextFieldDni.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		}
		return jTextFieldDni;
	}

	/**
	 * This method initializes jTextFieldEdad	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldEdad() {
		if (jTextFieldEdad == null) {
			jTextFieldEdad = new JTextField();
			jTextFieldEdad.setBounds(new Rectangle(76, 87, 180, 18));
			jTextFieldEdad.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		}
		return jTextFieldEdad;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(135, 5, 99, 21));
			jButton.setText("Salir");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					dispose();
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setBounds(new Rectangle(6, 5, 99, 21));
			jButton1.setText("Guardar");
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
				
				if (!jTextFieldNombre.getText().equals("") && !jTextFieldApellido.getText().equals("") && !jTextFieldDni.getText().equals("") && !jTextFieldEdad.getText().equals("")){
					
					if ((jTextFieldNombre.getText().length() <= 20) && (jTextFieldApellido.getText().length() <= 20) && (jTextFieldDni.getText().length() <= 10) && (jTextFieldEdad.getText().length() <= 2)){
						
						try {
							Integer.parseInt(jTextFieldDni.getText());
							Integer.parseInt(jTextFieldEdad.getText());
							
							
							Abm a = new Abm (jTextFieldDni.getText(),jTextFieldNombre.getText(),jTextFieldApellido.getText(),(String)jComboBox.getSelectedItem(),Integer.parseInt(jTextFieldEdad.getText()));
												
							try {
								
								Conexion.conectar();
								Conexion.agregar(a);
								Conexion.desconectar();
								jTextFieldNombre.setText("");
								jTextFieldApellido.setText("");
								jTextFieldDni.setText("");
								jTextFieldEdad.setText("");
								
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
													
						} catch (NumberFormatException e3){
							JOptionPane.showMessageDialog(rootPane, "Num. de Decumento y Edad \ntienen que ser n�mericos", "Error", JOptionPane.ERROR_MESSAGE);
						}
					}else {
						JOptionPane.showMessageDialog(rootPane, "Datos ingresados exceden el m�ximo permitido", "Error", JOptionPane.ERROR_MESSAGE);}
				}else {
					JOptionPane.showMessageDialog(rootPane, "Los campos no pueden estar en blanco", "Error", JOptionPane.ERROR_MESSAGE);
				}
				}
			});
		}
		return jButton1;
	}

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setLayout(null);
			jPanel.setBounds(new Rectangle(15, 111, 241, 33));
			jPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jPanel.add(getJButton(), null);
			jPanel.add(getJButton1(), null);
		}
		return jPanel;
	}

}  //  @jve:decl-index=0:visual-constraint="15,19"
